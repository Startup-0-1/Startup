 #!/bin/bash
 
 sqlite3 db.sqlite3 "DELETE FROM django_admin_log;"