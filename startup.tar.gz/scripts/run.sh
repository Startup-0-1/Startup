#!/bin/bash

python3 manage.py runserver